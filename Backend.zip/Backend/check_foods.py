from database import get_connection, DATABASE

print("CHECK DATABASE PATH:", DATABASE)
conn = get_connection()
cursor = conn.cursor()

cursor.execute("SELECT Food_id, Food_name, Image FROM food_menu")

rows = cursor.fetchall()

print("TOTAL ROWS:", len(rows))

for row in rows:
    print(row["Food_id"], row["Food_name"], row["Image"])

conn.close()